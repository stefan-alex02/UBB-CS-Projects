export interface ItemProps {
  _id?: string;
  text: string;
}
